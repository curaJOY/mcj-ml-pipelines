from typing import List, Optional, Union, Iterable
import spacy
import copy
from spacy.training import Example

from ..models.matcher import PatternMatcher
from ..models.textcat import TextClassifier, add_text_classifier, infer_exclusive
from ..components.loaders import get_stream
from ..components.preprocess import add_label_options, add_labels_to_stream
from ..components.preprocess import make_raw_doc
from ..components.sorters import prefer_uncertain
from ..components.db import connect
from ..core import recipe
from ..util import combine_models, log, msg, get_labels, split_string, INPUT_HASH_ATTR
from ..types import TaskType, StreamType, RecipeSettingsType


@recipe(
    "textcat.teach",
    # fmt: off
    dataset=("Dataset to save annotations to", "positional", None, str),
    spacy_model=("Loadable spaCy pipeline or blank:lang (e.g. blank:en)", "positional", None, str),
    source=("Data to annotate (file path or '-' to read from standard input)", "positional", None, str),
    loader=("Loader (guessed from file extension if not set)", "option", "lo", str),
    label=("Comma-separated label(s) to annotate or text file with one label per line", "option", "l", get_labels),
    patterns=("Path to match patterns file", "option", "pt", str),
    exclude=("Comma-separated list of dataset IDs whose annotations to exclude", "option", "e", split_string),
    # fmt: on
)
def teach(
    dataset: str,
    spacy_model: str,
    source: Union[str, Iterable[dict]],
    label: Optional[List[str]] = None,
    patterns: Optional[str] = None,
    loader: Optional[str] = None,
    exclude: Optional[List[str]] = None,
) -> RecipeSettingsType:
    """
    Collect the best possible training data for a text classification model
    with the model in the loop. Based on your annotations, Prodigy will decide
    which questions to ask next.
    """
    log("RECIPE: Starting recipe textcat.teach", locals())
    if label is None:
        msg.fail("textcat.teach requires at least one --label", exits=1)
    nlp = spacy.load(spacy_model)
    name = add_text_classifier(nlp, label)
    model = TextClassifier(nlp=nlp, labels=label, pipe_name=name)
    log(f"RECIPE: Creating TextClassifier with model {spacy_model}")
    stream = get_stream(
        source, loader=loader, rehash=True, dedup=True, input_key="text"
    )
    if patterns is None:
        predict = model
        update = model.update
    else:
        matcher = PatternMatcher(
            nlp,
            prior_correct=5.0,
            prior_incorrect=5.0,
            label_span=False,
            label_task=True,
            filter_labels=label,
            combine_matches=True,
            task_hash_keys=("label",),
        )
        matcher = matcher.from_disk(patterns)
        log("RECIPE: Created PatternMatcher and loaded in patterns", patterns)
        # Combine the textcat model with the PatternMatcher to annotate both
        # match results and predictions, and update both models.
        predict, update = combine_models(model, matcher)
    stream = prefer_uncertain(predict(stream))
    return {
        "view_id": "classification",
        "dataset": dataset,
        "stream": stream,
        "exclude": exclude,
        "update": update,
        "config": {"lang": nlp.lang, "labels": label},
    }


@recipe(
    "textcat.manual",
    # fmt: off
    dataset=("Dataset to save annotations to", "positional", None, str),
    source=("Data to annotate (file path or '-' to read from standard input)", "positional", None, str),
    loader=("Loader (guessed from file extension if not set)", "option", "lo", str),
    label=("Comma-separated label(s) to annotate or text file with one label per line", "option", "l", get_labels),
    exclusive=("Treat classes as mutually exclusive (if not set, an example can have multiple correct classes)", "flag", "E", bool),
    exclude=("Comma-separated list of dataset IDs whose annotations to exclude", "option", "e", split_string),
    # fmt: on
)
def manual(
    dataset: str,
    source: Union[str, Iterable[dict]],
    loader: Optional[str] = None,
    label: Optional[List[str]] = None,
    exclusive: bool = False,
    exclude: Optional[List[str]] = None,
) -> RecipeSettingsType:
    """
    Manually annotate categories that apply to a text. If more than one label
    is specified, categories are added as multiple choice options. If the
    --exclusive flag is set, categories become mutually exclusive, meaning that
    only one can be selected during annotation.
    """
    log("RECIPE: Starting recipe textcat.manual", locals())
    labels = label
    if not labels:
        msg.fail("textcat.manual requires at least one --label", exits=1)
    has_options = len(labels) > 1
    log(f"RECIPE: Annotating with {len(labels)} labels", labels)
    stream = get_stream(
        source, loader=loader, rehash=True, dedup=True, input_key="text"
    )
    if has_options:
        stream = add_label_options(stream, label)
    else:
        stream = add_labels_to_stream(stream, label)
        if exclusive:
            # Use the dataset to decide what's left to annotate
            db = connect()
            if dataset in db:
                stream = filter_accepted_inputs(db.get_dataset(dataset), stream)

    return {
        "view_id": "choice" if has_options else "classification",
        "dataset": dataset,
        "stream": stream,
        "exclude": exclude,
        "config": {
            "labels": labels,
            "choice_style": "single" if exclusive else "multiple",
            "choice_auto_accept": exclusive,
            "exclude_by": "input" if has_options else "task",
            "auto_count_stream": True,
        },
    }


def filter_accepted_inputs(examples: List[TaskType], stream: StreamType) -> StreamType:
    # If a single label is annotated with --exclusive, we only want to show
    # examples that aren't yet in the dataset or examples that were not yet
    # accepted (i.e. that we don't yet know the answer for).
    accepted = set()
    for eg in examples:
        if eg["answer"] == "accept":
            accepted.add(eg[INPUT_HASH_ATTR])
    for eg in stream:
        if eg[INPUT_HASH_ATTR] not in accepted:
            yield eg


@recipe(
    "textcat.correct",
    # fmt: off
    dataset=("Dataset to save annotations to", "positional", None, str),
    spacy_model=("Loadable spaCy pipeline with a text classifier", "positional", None, str),
    source=("Data to annotate (file path or '-' to read from standard input)", "positional", None, str),
    loader=("Loader (guessed from file extension if not set)", "option", "lo", str),
    label=("Comma-separated label(s) to annotate or text file with one label per line", "option", "l", get_labels),
    update=("Whether to update the model during annotation", "flag", "UP", bool),
    exclude=("Comma-separated list of dataset IDs whose annotations to exclude", "option", "e", split_string),
    threshold=("Score threshold to pre-select label, e.g. 0.75 to select all labels with a score of 0.75 and above", "option", "t", float),
    component=("Name of text classifier component in the pipeline (will be guessed from pipeline if not set)", "option", "c", str),
    # fmt: on
)
def correct(
    dataset: str,
    spacy_model: str,
    source: Union[str, Iterable[dict]],
    loader: Optional[str] = None,
    label: Optional[List[str]] = None,
    update: bool = False,
    exclude: Optional[List[str]] = None,
    threshold: float = 0.5,
    component: Optional[str] = None,
) -> RecipeSettingsType:
    """
    Correct the model's predicted categories that apply to a text. Prodigy will
    infer whether the categories should be mutualy exclusive based on the
    component configuration.
    """
    log("RECIPE: Starting recipe textcat.correct", locals())
    nlp = spacy.load(spacy_model)
    labels = label
    component = get_textcat_component(nlp.pipe_names, component)
    exclusive = infer_exclusive(nlp, component)
    msg.info(
        f"Annotating {'exclusive' if exclusive else 'non-exclusive'} categories "
        f"based on '{component}' component config"
    )
    model_labels = nlp.pipe_labels.get(component, [])
    if not labels:
        labels = model_labels
        if not labels:
            msg.fail("No --label argument set and no labels found in model", exits=1)
        msg.text(f"Using {len(labels)} labels from model: {', '.join(labels)}")
    if not labels:
        msg.fail("textcat.correct requires at least one --label", exits=1)
    log(f"RECIPE: Annotating with {len(labels)} labels", labels)
    stream = get_stream(
        source, loader=loader, rehash=True, dedup=True, input_key="text"
    )

    def add_suggestions(stream: StreamType) -> StreamType:
        texts = ((eg["text"], eg) for eg in stream)
        for doc, eg in nlp.pipe(texts, as_tuples=True, batch_size=10):
            task = copy.deepcopy(eg)
            options = []
            selected = []
            for cat, score in doc.cats.items():
                if cat in labels:
                    options.append({"id": cat, "text": cat, "meta": f"{score:.2f}"})
                    if score >= threshold:
                        selected.append(cat)
            task["options"] = options
            task["accept"] = selected
            yield task

    def make_update(answers: List[TaskType]) -> None:
        log(f"RECIPE: Updating model with {len(answers)} answers")
        examples = []
        for eg in answers:
            if eg["answer"] == "accept":
                selected = eg.get("accept", [])
                cats = {
                    opt["id"]: 1.0 if opt["id"] in selected else 0.0
                    for opt in eg.get("options", [])
                }
                doc = make_raw_doc(nlp, eg)
                examples.append(Example.from_dict(doc, {"cats": cats}))
        nlp.update(examples)

    stream = add_suggestions(stream)
    # We only want to display a radio button if there's more than one label
    # otherwise, you couldn't unselect an exclusive label
    choice_style = "single" if exclusive and len(labels) > 1 else "multiple"

    return {
        "view_id": "choice",
        "dataset": dataset,
        "stream": stream,
        "update": make_update if update else None,
        "exclude": exclude,
        "config": {
            "choice_style": choice_style,
            "choice_auto_accept": choice_style == "single",
            "exclude_by": "input",
            "auto_count_stream": not update,
        },
    }


def get_textcat_component(pipe_names: List[str], component: Optional[str]) -> str:
    components = ["textcat", "textcat_multilabel"]
    err = (
        "Can't find component {} in pipeline. Available components: {}. Make "
        "sure that the pipeline you're using includes a trained text classifier "
        "that you can correct. If your component has a different name, you can "
        "use the --component option to specify it."
    )
    if component is None:
        for pipe in components:
            if pipe in pipe_names:
                return pipe
        msg.fail(err.format(f"({', '.join(components)})", pipe_names), exits=1)
    if component not in pipe_names:
        msg.fail(err.format(f"'{component}'", pipe_names), exits=1)
    return component
