from typing import List, Optional, Union, Iterable, Callable
import spacy
from spacy.tokens import Doc
from spacy.training import Example
from spacy.language import Language
import copy

from ..models.matcher import PatternMatcher
from ..components.preprocess import add_tokens, make_raw_doc
from ..components.loaders import get_stream
from ..core import recipe
from ..util import log, split_string, get_labels, msg, set_hashes, INPUT_HASH_ATTR
from ..types import TaskType, RecipeSettingsType, StreamType


@recipe(
    "spans.manual",
    # fmt: off
    dataset=("Dataset to save annotations to", "positional", None, str),
    spacy_model=("Loadable spaCy pipeline for tokenization or blank:lang (e.g. blank:en)", "positional", None, str),
    source=("Data to annotate (file path or '-' to read from standard input)", "positional", None, str),
    loader=("Loader (guessed from file extension if not set)", "option", "lo", str),
    label=("Comma-separated label(s) to annotate or text file with one label per line", "option", "l", get_labels),
    patterns=("Path to match patterns file", "option", "pt", str),
    exclude=("Comma-separated list of dataset IDs whose annotations to exclude", "option", "e", split_string),
    highlight_chars=("Allow highlighting individual characters instead of tokens", "flag", "C", bool),
    suggester=("Name of suggester function registered in spaCy's 'misc' registry. Will be used to validate annotations as they're submitted. Use the -F option to provide a custom Python file", "option", "sg", str),
    # fmt: on
)
def manual(
    dataset: str,
    spacy_model: str,
    source: Union[str, Iterable[dict]],
    loader: Optional[str] = None,
    label: Optional[List[str]] = None,
    patterns: Optional[str] = None,
    exclude: Optional[List[str]] = None,
    highlight_chars: bool = False,
    suggester: Optional[str] = None,
) -> RecipeSettingsType:
    """
    Annotate potentially overlapping and nested spans in the data. If
    patterns are provided, their matches are highlighted in the example, if
    available. The tokenizer is used to tokenize the incoming texts so the
    selection can snap to token boundaries. You can also set --highlight-chars
    for character-based highlighting.
    """
    log("RECIPE: Starting recipe spans.manual", locals())
    nlp = spacy.load(spacy_model)
    labels = label  # comma-separated list or path to text file
    if not labels:
        msg.fail("No --label argument set", exits=1)
    log(f"RECIPE: Annotating with {len(labels)} labels", labels)
    stream = get_stream(
        source, loader=loader, rehash=True, dedup=True, input_key="text"
    )
    if patterns is not None:
        pattern_matcher = PatternMatcher(
            nlp, combine_matches=True, all_examples=True, allow_overlap=True
        )
        pattern_matcher = pattern_matcher.from_disk(patterns)
        stream = (eg for _, eg in pattern_matcher(stream))
    # Add "tokens" key to the tasks, either with words or characters
    stream = add_tokens(nlp, stream, use_chars=highlight_chars)
    validate_func = validate_with_suggester(nlp, suggester) if suggester else None

    return {
        "view_id": "spans_manual",
        "dataset": dataset,
        "stream": stream,
        "exclude": exclude,
        "before_db": remove_tokens if highlight_chars else None,
        "validate_answer": validate_func,
        "config": {
            "lang": nlp.lang,
            "labels": labels,
            "exclude_by": "input",
            "ner_manual_highlight_chars": highlight_chars,
            "auto_count_stream": True,
        },
    }


def validate_with_suggester(
    nlp: Language, suggester_name: str
) -> Callable[[TaskType], None]:
    msg.info(f"Validating annotations against suggester function '{suggester_name}'")
    suggester = spacy.registry.get("misc", suggester_name)()

    def validate_answer(answer: TaskType) -> None:
        spans = answer.get("spans", [])
        if not spans:  # No need to run suggester if we don't have spans
            pass
        # Don't allow spans that are not compatible with the provided suggester
        words = [t["text"] for t in answer["tokens"]]
        spaces = [t.get("ws", True) for t in answer["tokens"]]
        doc = Doc(nlp.vocab, words=words, spaces=spaces)
        suggested_spans = suggester(doc)
        suggested_span_tuples = [(s[0], s[1]) for s in suggested_spans.data]
        text = answer["text"]
        annotated = {
            ((s["token_start"], s["token_end"] + 1)): text[s["start"] : s["end"]]
            for s in spans
        }
        for annotated_tuple, text in annotated.items():
            if annotated_tuple not in suggested_span_tuples:
                start, end = annotated_tuple
                err = (
                    f"Span with token offsets {start}:{end} ({text}) "
                    f"is not compatible with the provided suggester function "
                    f"'{suggester_name}'."
                )
                raise ValueError(err)

    return validate_answer


def remove_tokens(answers: List[TaskType]) -> List[TaskType]:
    """Remove token information from examples before they're placed in the
    database. Used if character highlighting is enabled."""
    for eg in answers:
        del eg["tokens"]
        if "spans" in eg:
            for span in eg["spans"]:
                del span["token_start"]
                del span["token_end"]
    return answers


@recipe(
    "spans.correct",
    # fmt: off
    dataset=("Dataset to save annotations to", "positional", None, str),
    spacy_model=("Loadable spaCy pipeline with a span categorizer", "positional", None, str),
    source=("Data to annotate (file path or '-' to read from standard input)", "positional", None, str),
    loader=("Loader (guessed from file extension if not set)", "option", "lo", str),
    label=("Comma-separated label(s) to annotate or text file with one label per line", "option", "l", get_labels),
    update=("Whether to update the model during annotation", "flag", "UP", bool),
    exclude=("Comma-separated list of dataset IDs whose annotations to exclude", "option", "e", split_string),
    component=("Name of spancat component in the pipeline", "option", "c", str),
    # fmt: on
)
def correct(
    dataset: str,
    spacy_model: str,
    source: Union[str, Iterable[dict]],
    loader: Optional[str] = None,
    label: Optional[List[str]] = None,
    update: bool = False,
    exclude: Optional[List[str]] = None,
    component: str = "spancat",
) -> RecipeSettingsType:
    """
    Correct a span categorizer predicting potentially overlapping and nested
    spans. Requires a spaCy pipeline with a trained SpanCategorizer and will
    show all spans in the given group.
    """
    log("RECIPE: Starting recipe spans.correct", locals())
    nlp = spacy.load(spacy_model)
    if component not in nlp.pipe_names:
        msg.fail(
            f"Can't find component '{component}' in pipeline. Make sure that the "
            f"pipeline you're using includes a trained span categorizer that you "
            f"can correct. If your component has a different name, you can use "
            f"the --component option to specify it.",
            exits=1,
        )
    labels = label
    model_labels = nlp.pipe_labels.get(component, [])
    if not labels:
        labels = model_labels
        if not labels:
            msg.fail("No --label argument set and no labels found in model", exits=1)
        msg.text(f"Using {len(labels)} labels from model: {', '.join(labels)}")
    log(f"RECIPE: Annotating with {len(labels)} labels", labels)
    key = nlp.get_pipe(component).key
    msg.text(f"""Reading spans from key '{key}': doc.spans["{key}"]""")
    stream = get_stream(
        source, loader=loader, rehash=True, dedup=True, input_key="text"
    )
    stream = add_tokens(nlp, stream)

    def make_tasks(nlp: Language, stream: StreamType) -> StreamType:
        """Add a 'spans' key to each example, with predicted spans."""
        texts = ((eg["text"], eg) for eg in stream)
        for doc, eg in nlp.pipe(texts, as_tuples=True, batch_size=10):
            task = copy.deepcopy(eg)
            spans = []
            for span in doc.spans[key]:
                if labels and span.label_ not in labels:
                    continue
                spans.append(
                    {
                        "token_start": span.start,
                        "token_end": span.end - 1,
                        "start": span.start_char,
                        "end": span.end_char,
                        "text": span.text,
                        "label": span.label_,
                        "source": spacy_model,
                        "input_hash": eg[INPUT_HASH_ATTR],
                    }
                )
            task["spans"] = spans
            task = set_hashes(task)
            yield task

    def make_update(answers: Iterable[dict]) -> None:
        log(f"RECIPE: Updating model with {len(answers)} answers")
        examples = []
        for eg in answers:
            if eg["answer"] == "accept":
                doc = make_raw_doc(nlp, eg)
                ref = make_raw_doc(nlp, eg)
                doc.spans[key] = [
                    doc.char_span(span["start"], span["end"], label=span["label"])
                    for span in eg.get("spans", [])
                ]
                examples.append(Example(doc, ref))
        nlp.update(examples)

    stream = make_tasks(nlp, stream)

    return {
        "view_id": "spans_manual",
        "dataset": dataset,
        "stream": stream,
        "update": make_update if update else None,
        "exclude": exclude,
        "config": {
            "lang": nlp.lang,
            "labels": labels,
            "exclude_by": "input",
            "auto_count_stream": True,
        },
    }
