from typing import List, Optional, Union, Sequence, Dict, Any, IO, Tuple
from spacy.cli import init_config as spacy_init_config
from spacy.cli.init_config import Optimizations, save_config
from spacy.cli.evaluate import handle_scores_per_type
from spacy.cli._util import parse_config_overrides, setup_gpu, show_validation_error
from spacy.util import load_config_from_str, load_config
from spacy.tokens import DocBin
from spacy.language import Language
from spacy.training.loop import train as spacy_train
from spacy.training.initialize import init_nlp as spacy_init_nlp
from spacy.training.loggers import console_logger as spacy_console_logger
from spacy.util import logger as spacy_logger
import spacy
from thinc.api import fix_random_seed, Config
from pathlib import Path
import logging
import srsly
import sys
import os

from .data_utils import logger, merge_data, get_datasets_from_cli, add_prodigy_readers
from .data_utils import load_examples, infer_spancat_suggester
from ..components.db import connect
from ..components.printers import train_curve_printer
from ..core import recipe
from ..util import log, split_string, msg
from ..util import NER_DEFAULT_INCORRECT_KEY, SPANCAT_DEFAULT_KEY


CONFIG_READER_PATH = Path(__file__).parent.parent / "default_config_reader.cfg"
# fmt: off
RECIPE_ARGS = {
    "lang": ("Language to use", "option", "l", str),
    "ner": ("Comma-separated NER datasets", "option", "n", split_string),
    "textcat": ("Comma-separated text classification datasets (exclusive categories)", "option", "tc", split_string),
    "textcat_multilabel": ("Comma-separated multi-label text classification datasets (non-exclusive categories) ", "option", "tcm", split_string),
    "tagger": ("Comma-separated tagging datasets", "option", "t", split_string),
    "senter": ("Comma-separated sentence datasets", "option", "s", split_string),
    "parser": ("Comma-separated dependency parsing datasets", "option", "p", split_string),
    "spancat": ("Comma-separated span categorizer datasets", "option", "sc", split_string),
    "ner_missing": ("DEPRECATED (NER): assume unannotated spans are missing values, not outside an entity", "flag", "NM", bool),
    "eval_split": ("Portion of examples to split off for evaluation. Defaults to 0.2.", "option", "es", float),
    "base_model": ("Optional base model to use for config, tokenization and sentence segmentation", "option", "m", str),
    "config": ("Optional path to spaCy config.cfg file to use for training", "option", "c", str),
    "gpu_id": ("GPU ID for training on GPU or -1 for CPU", "option", "g", int),
    "verbose": ("Enable verbose logging", "flag", "V", bool),
    "silent": ("Don't output any status or logs", "flag", "S", bool),
    "overrides": ("Config overrides", "positional", None, str),
}
# fmt: on


@recipe(
    "spacy-config",
    # fmt: off
    output_file=("Path to save config file or - for stdout)", "positional", None, str),
    lang=RECIPE_ARGS["lang"],
    ner=RECIPE_ARGS["ner"],
    textcat=RECIPE_ARGS["textcat"],
    textcat_multilabel=RECIPE_ARGS["textcat_multilabel"],
    tagger=RECIPE_ARGS["tagger"],
    senter=RECIPE_ARGS["senter"],
    parser=RECIPE_ARGS["parser"],
    spancat=RECIPE_ARGS["spancat"],
    ner_missing=RECIPE_ARGS["ner_missing"],
    eval_split=RECIPE_ARGS["eval_split"],
    config=RECIPE_ARGS["config"],
    base_model=RECIPE_ARGS["base_model"],
    verbose=RECIPE_ARGS["verbose"],
    silent=RECIPE_ARGS["silent"],
    # fmt: on
)
def prodigy_config(
    output_file: Optional[Union[str, Path]],
    lang: str = "en",
    ner: Sequence[str] = tuple(),
    textcat: Sequence[str] = tuple(),
    textcat_multilabel: Sequence[str] = tuple(),
    tagger: Sequence[str] = tuple(),
    senter: Sequence[str] = tuple(),
    parser: Sequence[str] = tuple(),
    spancat: Sequence[str] = tuple(),
    ner_missing: bool = False,
    eval_split: float = 0.2,
    config: Optional[Config] = None,
    base_model: Optional[str] = None,
    verbose: bool = False,
    silent: bool = False,
) -> Config:
    """
    Generate a starter config for training from Prodigy datasets. A custom reader
    will be used that merges annotations on the same examples.
    It's recommended to use the review recipe on the different annotation types
    first to resolve conflicts properly (instead of relying on this recipe to
    just filter conflicting annotations and decide on one).
    """
    set_log_level(verbose=verbose, silent=silent)
    is_stdout = output_file is not None and str(output_file) == "-"
    silent = is_stdout or silent
    msg.divider("Generating Prodigy config", show=not silent)
    pipes = get_datasets_from_cli(
        ner,
        textcat,
        textcat_multilabel,
        tagger,
        senter,
        parser,
        spancat,
    )
    base_nlp = spacy.load(base_model) if base_model is not None else None
    if config is None:
        config = generate_default_config(pipes, lang, base_nlp, silent=silent)
    config = generate_config(config, base_nlp, base_model, list(pipes), silent)
    # Removing the standard spaCy readers and adding the Prodigy reader instead
    corpus_config = load_config(CONFIG_READER_PATH)
    config = add_prodigy_readers(
        pipes,
        config,
        corpus_config,
        eval_split=eval_split,
        ner_missing=ner_missing,
    )
    msg.good("Generated training config", show=not silent)
    # If this recipe is called as a function, we can pass in None to return only
    if output_file is not None:
        output_file = Path(output_file)
        # Make sure to suppress the log from save_config, which would otherwise refer to --paths.train
        save_config(config, output_file, is_stdout=is_stdout, silent=True)
        if not is_stdout and not silent:
            msg.good("Saved training config", output_file)
            msg.text("You can now add your data and train your pipeline:")
            print(f"python -m spacy train {output_file.parts[-1]}")
    return config


def _train(
    config: Config,
    *,
    output_dir: Optional[Union[str, Path]] = None,
    gpu_id: int,
    overrides: Dict[str, Any],
    show_label_stats: bool = False,
    silent: bool = False,
) -> Tuple[Optional[Dict[str, Any]], Optional[Dict[str, Any]]]:
    # This is a small hack, but we're basically registering a custom logger so
    # we can track the full stats on each log step
    BASELINE = None
    SCORES = None

    @spacy.registry.loggers("prodigy.ConsoleLogger.v1")
    def console_logger(progress_bar: bool = False):
        spacy_setup_printer = spacy_console_logger(progress_bar)

        def setup_printer(
            nlp: Language, stdout: IO = sys.stdout, stderr: IO = sys.stderr
        ):
            spacy_log_step, finalize = spacy_setup_printer(nlp, stdout, stderr)

            def log_step(info: Optional[Dict[str, Any]]) -> None:
                nonlocal SCORES, BASELINE
                if info:
                    if BASELINE is None:
                        BASELINE = info
                    if not SCORES or info["score"] > SCORES["score"]:
                        SCORES = info
                spacy_log_step(info)

            return log_step, finalize

        return setup_printer

    original_logger = config["training"].get("logger")

    @spacy.registry.misc("prodigy.todisk_cleanup.v1")
    def create_callback():
        def cleanup_config(nlp):
            if original_logger:
                nlp.config["training"]["logger"] = original_logger
            nlp.config["training"]["before_to_disk"] = None
            return nlp

        return cleanup_config

    config["training"]["logger"] = {"@loggers": "prodigy.ConsoleLogger.v1"}
    config["training"]["before_to_disk"] = {"@misc": "prodigy.todisk_cleanup.v1"}

    msg.divider("Initializing pipeline", show=not silent)
    with show_validation_error(None, hint_fill=False):
        config = load_config_from_str(config.to_str(), overrides=overrides)
        nlp = spacy_init_nlp(config, use_gpu=gpu_id)
    msg.good("Initialized pipeline", show=not silent)
    msg.divider("Training pipeline", show=not silent)
    stdout = sys.stdout if not silent else open(os.devnull, "w", encoding="utf-8")
    output_path = Path(output_dir) if output_dir is not None else None
    if output_path is not None and not output_path.exists():
        output_path.mkdir(parents=True)
    try:
        spacy_train(nlp, output_path, use_gpu=gpu_id, stdout=stdout)
        if show_label_stats:
            handle_scores_per_type(SCORES.get("other_scores", {}), silent=silent)
        return BASELINE, SCORES
    except KeyboardInterrupt:
        msg.warn("Aborted", exits=0)
    return BASELINE, SCORES


@recipe(
    "train",
    # fmt: off
    output_dir=("Optional output directory for the trained pipeline", "positional", None, str),
    ner=RECIPE_ARGS["ner"],
    textcat=RECIPE_ARGS["textcat"],
    textcat_multilabel=RECIPE_ARGS["textcat_multilabel"],
    tagger=RECIPE_ARGS["tagger"],
    senter=RECIPE_ARGS["senter"],
    parser=RECIPE_ARGS["parser"],
    spancat=RECIPE_ARGS["spancat"],
    ner_missing=RECIPE_ARGS["ner_missing"],
    eval_split=RECIPE_ARGS["eval_split"],
    label_stats=("Show per-label scores", "flag", "LS", bool),
    config=RECIPE_ARGS["config"],
    base_model=RECIPE_ARGS["base_model"],
    lang=RECIPE_ARGS["lang"],
    gpu_id=RECIPE_ARGS["gpu_id"],
    verbose=RECIPE_ARGS["verbose"],
    silent=RECIPE_ARGS["silent"],
    overrides=RECIPE_ARGS["overrides"],
    # fmt: on
)
def train(
    output_dir: Union[str, Path] = None,
    ner: Sequence[str] = tuple(),
    textcat: Sequence[str] = tuple(),
    textcat_multilabel: Sequence[str] = tuple(),
    tagger: Sequence[str] = tuple(),
    senter: Sequence[str] = tuple(),
    parser: Sequence[str] = tuple(),
    spancat: Sequence[str] = tuple(),
    ner_missing: bool = False,
    eval_split: float = 0.2,
    label_stats: bool = False,
    config: Optional[Union[str, Path]] = None,
    base_model: Optional[str] = None,
    lang: str = "en",
    gpu_id: int = -1,
    verbose: bool = False,
    silent: bool = False,
    *overrides,
) -> Tuple[Optional[Dict[str, Any]], Optional[Dict[str, Any]]]:
    """Train a spaCy pipeline from one or more datasets for different components.
    Per-component evaluation sets can be provided using the eval: prefix, e.g.
    --ner my_train_dataset,eval:my_eval_dataset. The command takes care of
    auto-generating a training config and merging all annotations on the
    same input data.
    """
    set_log_level(verbose=verbose, silent=silent)
    setup_gpu(gpu_id)
    overrides = parse_config_overrides(list(overrides))
    if config is not None:
        config = load_config(config)
    train_config = prodigy_config(
        None,
        lang=lang,
        ner=ner,
        textcat=textcat,
        textcat_multilabel=textcat_multilabel,
        tagger=tagger,
        senter=senter,
        parser=parser,
        spancat=spancat,
        ner_missing=ner_missing,
        eval_split=eval_split,
        config=config,
        base_model=base_model,
        verbose=verbose,
        silent=silent,
    )
    return _train(
        train_config,
        output_dir=output_dir,
        gpu_id=gpu_id,
        overrides=overrides,
        show_label_stats=label_stats,
        silent=silent,
    )


@recipe(
    "train-curve",
    # fmt: off
    ner=RECIPE_ARGS["ner"],
    textcat=RECIPE_ARGS["textcat"],
    textcat_multilabel=RECIPE_ARGS["textcat_multilabel"],
    tagger=RECIPE_ARGS["tagger"],
    senter=RECIPE_ARGS["senter"],
    parser=RECIPE_ARGS["parser"],
    spancat=RECIPE_ARGS["spancat"],
    ner_missing=RECIPE_ARGS["ner_missing"],
    eval_split=RECIPE_ARGS["eval_split"],
    config=RECIPE_ARGS["config"],
    base_model=RECIPE_ARGS["base_model"],
    lang=RECIPE_ARGS["lang"],
    gpu_id=RECIPE_ARGS["gpu_id"],
    overrides=RECIPE_ARGS["overrides"],
    n_samples=("Number of samples to take for train curve", "option", "ns", int),
    show_plot=("Show a visual plot of the curve (requires the plotext library)", "flag", "P", bool),
    # fmt: on
)
def train_curve(
    ner: Sequence[str] = tuple(),
    textcat: Sequence[str] = tuple(),
    textcat_multilabel: Sequence[str] = tuple(),
    tagger: Sequence[str] = tuple(),
    senter: Sequence[str] = tuple(),
    parser: Sequence[str] = tuple(),
    spancat: Sequence[str] = tuple(),
    ner_missing: bool = False,
    eval_split: float = 0.2,
    config: Optional[str] = None,
    base_model: Optional[str] = None,
    lang: str = "en",
    gpu_id: int = -1,
    n_samples: int = 4,
    show_plot: bool = False,
    *overrides,
) -> None:
    """
    Train a spaCy pipeline with different portions of the training examples and
    print the accuracy figures and accuracy improvements with more data. Can be
    used to get an idea of whether more annotations could improve the model.
    This recipe takes pretty much the same arguments as `train`.
    """
    set_log_level(silent=True)
    msg.divider("Generating Prodigy config")
    overrides = parse_config_overrides(list(overrides))
    pipes = get_datasets_from_cli(
        ner,
        textcat,
        textcat_multilabel,
        tagger,
        senter,
        parser,
        spancat,
    )
    base_nlp = spacy.load(base_model) if base_model is not None else None
    if config is None:
        config = generate_default_config(pipes, lang, base_nlp)
    else:
        config = load_config(config)
    config = generate_config(config, base_nlp, base_model, list(pipes))
    # Removing the standard spaCy readers and adding the Prodigy reader instead
    corpus_config = load_config(CONFIG_READER_PATH)
    config = add_prodigy_readers(
        pipes,
        config,
        corpus_config,
        eval_split=eval_split,
        ner_missing=ner_missing,
    )
    msg.good("Generated training config")

    msg.divider("Train curve diagnostic")
    spancat_key = config["components"].get("spancat", {}).get("spans_key", "sc")
    default_scores = {
        "ner": "ents_f",
        "parser": "dep_uas",
        "tagger": "tag_acc",
        "senter": "sents_f",
        "textcat": "cats_score",
        "textcat_multilabel": "cats_score",
        "spancat": f"spans_{spancat_key}_f",
    }
    factors = [(i + 1) / n_samples for i in range(n_samples)]
    prev_scores = None
    pcs = ", ".join([f"{fac:.0%}" for fac in factors])
    msg.text(f"Training {n_samples} times with {pcs} of the data")
    with train_curve_printer(list(pipes), default_scores, show_plot) as result:
        for i, factor in enumerate(factors):
            config["corpora"]["sample_size"] = factor
            baseline, scores = _train(
                config, gpu_id=gpu_id, overrides=overrides, silent=True
            )
            if i == 0:
                result(0, baseline, None)
                prev_scores = baseline
            result(factor, scores, prev_scores)
            prev_scores = scores


@recipe(
    "data-to-spacy",
    # fmt: off
    output_dir=("Path to output directory", "positional", None, str),
    ner=RECIPE_ARGS["ner"],
    textcat=RECIPE_ARGS["textcat"],
    textcat_multilabel=RECIPE_ARGS["textcat_multilabel"],
    tagger=RECIPE_ARGS["tagger"],
    senter=RECIPE_ARGS["senter"],
    parser=RECIPE_ARGS["parser"],
    spancat=RECIPE_ARGS["spancat"],
    ner_missing=RECIPE_ARGS["ner_missing"],
    eval_split=RECIPE_ARGS["eval_split"],
    config=RECIPE_ARGS["config"],
    base_model=RECIPE_ARGS["base_model"],
    lang=RECIPE_ARGS["lang"],
    verbose=RECIPE_ARGS["verbose"],
    # fmt: on
)
def data_to_spacy(
    output_dir: Union[str, Path],
    ner: Sequence[str] = tuple(),
    textcat: Sequence[str] = tuple(),
    textcat_multilabel: Sequence[str] = tuple(),
    tagger: Sequence[str] = tuple(),
    senter: Sequence[str] = tuple(),
    parser: Sequence[str] = tuple(),
    spancat: Sequence[str] = tuple(),
    ner_missing: bool = False,
    eval_split: float = 0.2,
    config: Optional[Config] = None,
    base_model: Optional[str] = None,
    lang: str = "en",
    verbose: bool = False,
) -> None:
    """
    Combine multiple datasets, merge annotations on the same examples and output
    a file in spaCy's binary training format that you can use with `spacy train`.
    It's recommended to use the review recipe on the different annotation types
    first to resolve conflicts properly (instead of relying on this recipe to
    just filter conflicting annotations and decide on one).

    The command takes an output directory and generates all data required to
    train a pipeline with spaCy, including the config and pre-generated labels
    data to speed up the training process.
    """
    logger.setLevel(logging.DEBUG if verbose else logging.INFO)
    log("RECIPE: Starting recipe data-to-spacy", locals())
    output_path = Path(output_dir)
    if output_path.exists() and not output_path.is_dir():
        msg.fail("Can't save to output path: not a directory", output_path, exist=1)
    if not output_path.exists():
        output_path.mkdir(parents=True)
        msg.good("Created output directory")
    fix_random_seed(0)
    if base_model is not None:
        msg.info(f"Using base model '{base_model}'")
        nlp = spacy.load(base_model)
    else:
        msg.info(f"Using language '{lang}'")
        nlp = spacy.blank(lang)
        nlp.add_pipe("sentencizer")

    msg.divider("Generating data")
    train_docs, dev_docs, pipes = merge_data(
        nlp,
        ner,
        textcat,
        textcat_multilabel,
        tagger,
        senter,
        parser,
        spancat,
        ner_missing=ner_missing,
        eval_split=eval_split,
    )
    if not train_docs:
        msg.fail(
            "No training data. This can happen if all your datasets are empty "
            "or if no valid annotations for the given component were found. For "
            'more details, make sure you\'ve set "validate": true in your '
            "prodigy.json, and use the --verbose flag for more output.",
            exits=1,
        )
    train_path = output_path / "train.spacy"
    dev_path = output_path / "dev.spacy"
    DocBin(docs=train_docs).to_disk(train_path)
    msg.good(f"Saved {len(train_docs)} training examples", train_path)
    if dev_docs:
        DocBin(docs=dev_docs).to_disk(dev_path)
        msg.good(f"Saved {len(dev_docs)} evaluation examples", dev_path)
    else:
        msg.warn(
            "No evaluation data. You can provide dedicated evaluation sets for "
            "the different components using the eval: prefix, or set an "
            "--eval-split to hold back a percentage for evaluation. "
            "If you already have a dev set available, you can specify its "
            "correct path as the '--paths.dev' argument to 'spacy train'.",
        )

    msg.divider("Generating config")
    base_nlp = nlp if base_model is not None else None
    if config is None:
        config = generate_default_config(pipes, lang, base_nlp)
    config = generate_config(config, base_nlp, base_model, list(pipes))
    msg.good("Generated training config")

    msg.divider("Generating cached label data")
    config["paths"]["train"] = str(train_path)
    config["paths"]["dev"] = str(dev_path)
    # We need to initialize the nlp object here to make label_data available
    nlp = spacy_init_nlp(config)
    labels_path = output_path / "labels"
    if not labels_path.exists():
        labels_path.mkdir()
    generated_pipes = []
    for name, component in nlp.pipeline:
        if getattr(component, "label_data", None) is not None:
            generated_pipes.append(name)
            output_file = labels_path / f"{name}.json"
            srsly.write_json(output_file, component.label_data)
            msg.good(f"Saving label data for component '{name}'", output_file)
            # Not very elegant, but should work
            reader = {"@readers": "spacy.read_labels.v1", "path": str(output_file)}
            config["initialize"]["components"][name] = {"labels": reader}
    config["paths"]["train"] = None
    config["paths"]["dev"] = None
    if not generated_pipes:
        msg.info("No components to generate cached label data for")

    msg.divider("Finalizing export")
    config_path = output_path / "config.cfg"
    save_config(config, config_path, silent=True)
    msg.good("Saved training config", config_path)
    cmd = f"python -m spacy train {config_path} --paths.train {train_path} --paths.dev {dev_path}"
    print("\nTo use this data for training with spaCy, you can run:")
    print(cmd)


def generate_default_config(
    pipe_datasets: Dict[str, Tuple[List[str], List[str]]],
    lang: str,
    nlp: Optional[Language],
    *,
    silent: bool = False,
    infer_from_data: bool = True,
) -> Config:
    msg.info("Auto-generating config with spaCy", show=not silent)
    pipes = list(pipe_datasets)
    config = spacy_init_config(
        lang=lang,
        pipeline=pipes,
        optimize=Optimizations.efficiency.value,
        gpu=False,
    )
    if "ner" in config["components"]:
        config["components"]["ner"]["incorrect_spans_key"] = NER_DEFAULT_INCORRECT_KEY
    if "beam_ner" in config["components"]:
        config["components"]["beam_ner"][
            "incorrect_spans_key"
        ] = NER_DEFAULT_INCORRECT_KEY
    if "spancat" in config["components"]:
        config["components"]["spancat"]["spans_key"] = SPANCAT_DEFAULT_KEY
        prefix = f"spans_{SPANCAT_DEFAULT_KEY}"
        # This isn't perfect yet because the default 'spans_sc_f' will still show up. But we're setting the
        # Prodigy default to the same as the spaCy default ("sc"), so this should hopefully not come up.
        config["training"]["score_weights"][f"{prefix}_f"] = 1.0
        config["training"]["score_weights"][f"{prefix}_p"] = 0.0
        config["training"]["score_weights"][f"{prefix}_r"] = 0.0
    # TODO: not sure if we ever want this to be False, but left the setting in
    # here just in case
    if infer_from_data:
        # We reload the datasets here because all we care about is the raw data
        # and going via the readers adds too much complexity. Keeping it here
        # for simplicity but if this gets longer we can move it to helper.
        if nlp is None:
            nlp = spacy.blank(lang)
        db = connect()
        if "spancat" in config["components"]:
            train_sets, dev_sets = pipe_datasets["spancat"]
            examples = load_examples(db, [*train_sets, *dev_sets])
            suggester = infer_spancat_suggester(examples, nlp)
            config["components"]["spancat"]["suggester"] = suggester
    return config


def generate_config(
    config: Config,
    base_nlp: Optional[Language],
    base_name: Optional[Union[str, Path]],
    pipes: List[str],
    silent: bool = False,
) -> Config:
    for pipe in pipes:
        if pipe not in config["components"]:
            msg.warn(f"Component '{pipe}' is not defined in the provided config")

    if base_nlp is not None and base_name is not None:
        tok2vec_pipes = ["tok2vec", "transformer"]
        orig_pipes = config["nlp"]["pipeline"]
        # We want to keep the nlp and training settings here (if training
        # config differs from default, e.g. for transformers)
        config["nlp"] = base_nlp.config["nlp"]
        config["training"] = base_nlp.config["training"]
        # we reset the logger to a default one, to avoid
        # forcing the user to install wandb (cf 3.0 and 3.1 spaCy models)
        del config["training"]["logger"]
        if len(base_nlp.vocab.vectors.keys()) > 0:
            config["initialize"]["vectors"] = base_name
        # Make sure we have a simple list, not a SimpleFrozenList
        # ensure we keep the downstream embedding layers (without duplicating them)
        final_pipes = [
            p for p in tok2vec_pipes if p in orig_pipes and p not in base_nlp.pipe_names
        ]
        final_pipes.extend(list(base_nlp.pipe_names))
        for pipe in pipes:
            if pipe not in final_pipes:
                final_pipes.append(pipe)
        config["nlp"]["pipeline"] = final_pipes

        msg.info("Using config from base model", show=not silent)
        active_pipes = [*pipes, *tok2vec_pipes]
        # If we're auto-freezing components that are present in the base pipeline
        # but shouldn't be updated during training, make sure we're also
        # replacing their listeners with a standalone tok2vec model, so their
        # performance stays stable while updating other components
        # TODO: Should we try and be clever here and replace the tok2vec(s)
        # with the least dependencies?
        listening_components = []
        for pipe in tok2vec_pipes:
            if pipe in base_nlp.pipe_names:
                proc = base_nlp.get_pipe(pipe)
                if getattr(proc, "listening_components", None):
                    listening_components.extend(proc.listening_components)
        for pipe in base_nlp.pipe_names:
            cfg = {"source": base_name}
            if pipe not in active_pipes and pipe in listening_components:
                cfg["replace_listeners"] = ["model.tok2vec"]
            config["components"][pipe] = cfg
        # Freeze components that are not trained from Prodigy annotations
        frozen = [p for p in base_nlp.pipe_names if p not in active_pipes]
        not_frozen = [p for p in base_nlp.pipe_names if p in active_pipes]
        config["training"]["frozen_components"] = frozen
        # Unset score weights for all other components so we're only outputting
        # the relevant scores in Prodigy (more intuitive)
        score_names_keep = set()
        for pipe in not_frozen:
            pipe_meta = base_nlp.get_pipe_meta(pipe)
            for score_name in pipe_meta.scores:
                score_names_keep.add(score_name)
        for pipe in frozen:
            pipe_meta = base_nlp.get_pipe_meta(pipe)
            for score_name in pipe_meta.scores:
                if (
                    score_name in config["training"]["score_weights"]
                    and score_name not in score_names_keep
                ):
                    config["training"]["score_weights"][score_name] = None
    return config


def set_log_level(*, verbose: bool = False, silent: bool = False) -> None:
    level = logging.ERROR if silent else logging.DEBUG if verbose else logging.INFO
    logger.setLevel(level)
    spacy_logger.setLevel(level)
