from typing import List, Optional, Union, Iterable
import spacy
from spacy.language import Language
import copy

from ..models.tag import Tagger, ensure_tagger
from ..components.loaders import get_stream
from ..components.preprocess import split_sentences, add_tokens
from ..components.sorters import prefer_uncertain
from ..core import recipe
from ..util import log, set_hashes, msg, split_string, get_labels, INPUT_HASH_ATTR
from ..types import StreamType, RecipeSettingsType


@recipe(
    "pos.teach",
    # fmt: off
    dataset=("Dataset to save annotations to", "positional", None, str),
    spacy_model=("Loadable spaCy pipeline with a tagger", "positional", None, str),
    source=("Data to annotate (file path or '-' to read from standard input)", "positional", None, str),
    loader=("Loader (guessed from file extension if not set)", "option", "lo", str),
    label=("Comma-separated label(s) to annotate or text file with one label per line", "option", "l", get_labels),
    exclude=("Comma-separated list of dataset IDs whose annotations to exclude", "option", "e", split_string),
    unsegmented=("Don't split sentences", "flag", "U", bool),
    # fmt: on
)
def teach(
    dataset: str,
    spacy_model: str,
    source: Union[str, Iterable[dict]],
    loader: Optional[str] = None,
    label: Optional[List[str]] = None,
    exclude: Optional[List[str]] = None,
    unsegmented: bool = False,
    filter: bool = True,
) -> RecipeSettingsType:
    """
    Collect the best possible training data for a part-of-speech tagging
    model with the model in the loop. Based on your annotations, Prodigy will
    decide which questions to ask next.
    """
    log("RECIPE: Starting recipe pos.teach", locals())
    stream = get_stream(
        source, loader=loader, rehash=True, dedup=True, input_key="text"
    )
    log(f"RECIPE: Creating Tagger using model {spacy_model}")
    labels = label
    nlp = spacy.load(spacy_model)
    ensure_tagger(nlp, "tagger")
    if not labels:
        labels = nlp.pipe_labels.get("tagger", [])
        if not labels:
            msg.fail("No --label argument set and no labels found in model", exits=1)
        msg.text(f"Using {len(labels)} labels from model: {', '.join(labels)}")
    log(f"RECIPE: Annotating with {len(labels)} labels", labels)
    model = Tagger(nlp, label=labels)
    if not unsegmented:
        stream = split_sentences(nlp, stream)
    stream = add_tokens(nlp, stream)  # add tokens for faster annotation
    if filter:
        stream = prefer_uncertain(model(stream), algorithm="probability")
    else:
        stream = (eg for _, eg in model(stream))

    return {
        "view_id": "pos",
        "dataset": dataset,
        "stream": stream,
        "update": model.update,
        "exclude": exclude,
        "config": {
            "lang": nlp.lang,
            "label": ", ".join(labels) if label is not None else "all",
        },
    }


@recipe(
    "pos.correct",
    # fmt: off
    dataset=("Dataset to save annotations to", "positional", None, str),
    spacy_model=("Loadable spaCy pipeline with a tagger", "positional", None, str),
    source=("Data to annotate (file path or '-' to read from standard input)", "positional", None, str),
    loader=("Loader (guessed from file extension if not set)", "option", "lo", str),
    label=("Comma-separated label(s) to annotate or text file with one label per line", "option", "l", get_labels),
    exclude=("Comma-separated list of dataset IDs whose annotations to exclude", "option", "e", split_string),
    unsegmented=("Don't split sentences", "flag", "U", bool),
    # fmt: on,
)
def make_gold(
    dataset: str,
    spacy_model: str,
    source: Union[str, Iterable[dict]],
    loader: Optional[str] = None,
    label: Optional[List[str]] = None,
    exclude: Optional[List[str]] = None,
    unsegmented: bool = False,
) -> RecipeSettingsType:
    """
    Create gold data for part-of-speech tags by correcting a model's
    predictions.
    """
    log("RECIPE: Starting recipe pos.correct", locals())
    nlp = spacy.load(spacy_model)
    log(f"RECIPE: Loaded model {spacy_model}")
    labels = label  # comma-separated list of path to text file
    if not labels:
        labels = nlp.pipe_labels.get("tagger", [])
        if not labels:
            msg.fail("No --label argument set and no labels found in model", exits=1)
        msg.text(f"Using {len(labels)} labels from model: {', '.join(labels)}")
    log(f"RECIPE: Annotating with {len(labels)} labels", labels)
    stream = get_stream(
        source, loader=loader, rehash=True, dedup=True, input_key="text"
    )
    if not unsegmented:
        stream = split_sentences(nlp, stream)
    stream = add_tokens(nlp, stream)  # add tokens for faster annotation

    def make_tasks(nlp: Language, stream: StreamType) -> StreamType:
        """Add a 'spans' key to each example, with predicted tags."""
        texts = ((eg["text"], eg) for eg in stream)
        for doc, eg in nlp.pipe(texts, as_tuples=True, batch_size=10):
            task = copy.deepcopy(eg)
            spans = []
            for i, token in enumerate(doc):
                tag = token.tag_
                if labels and tag not in labels:
                    continue
                spans.append(
                    {
                        "token_start": i,
                        "token_end": i,
                        "start": token.idx,
                        "end": token.idx + len(token.text),
                        "text": token.text,
                        "label": tag,
                        "source": spacy_model,
                        "input_hash": eg[INPUT_HASH_ATTR],
                    }
                )
            task["spans"] = spans
            task = set_hashes(task)
            yield task

    stream = make_tasks(nlp, stream)

    return {
        "view_id": "pos_manual",
        "dataset": dataset,
        "stream": stream,
        "exclude": exclude,
        "config": {
            "lang": nlp.lang,
            "labels": labels,
            "exclude_by": "input",
            "auto_count_stream": True,
        },
    }


# Set alias for old deprecated name
recipe("pos.make-gold", **make_gold.__annotations__)(make_gold)
