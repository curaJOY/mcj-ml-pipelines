from . import dep, ner, textcat, pos, sent, compare, terms, generic, image  # noqa
from . import rel, coref, audio, review, train, commands, spans  # noqa
