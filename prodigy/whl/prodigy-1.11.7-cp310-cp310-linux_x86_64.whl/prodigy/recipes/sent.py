from typing import List, Optional, Union, Iterable
import spacy
from spacy.language import Language
import copy

from ..models.tag import Tagger, ensure_tagger
from ..components.loaders import get_stream
from ..components.preprocess import add_tokens
from ..components.sorters import prefer_uncertain
from ..core import recipe
from ..util import log, set_hashes, split_string, INPUT_HASH_ATTR, SENT_START_LABEL
from ..util import BINARY_ATTR
from ..types import StreamType, RecipeSettingsType


@recipe(
    "sent.teach",
    # fmt: off
    dataset=("Dataset to save annotations to", "positional", None, str),
    spacy_model=("Loadable spaCy pipeline with a senter", "positional", None, str),
    source=("Data to annotate (file path or '-' to read from standard input)", "positional", None, str),
    loader=("Loader (guessed from file extension if not set)", "option", "lo", str),
    exclude=("Comma-separated list of dataset IDs whose annotations to exclude", "option", "e", split_string),
    # fmt: on
)
def teach(
    dataset: str,
    spacy_model: str,
    source: Union[str, Iterable[dict]],
    loader: Optional[str] = None,
    exclude: Optional[List[str]] = None,
) -> RecipeSettingsType:
    """
    Collect the best possible training data for a sentence recognizer
    model with the model in the loop. Based on your annotations, Prodigy will
    decide which questions to ask next.
    """
    log("RECIPE: Starting recipe sent.teach", locals())
    stream = get_stream(
        source, loader=loader, rehash=True, dedup=True, input_key="text"
    )
    log(f"RECIPE: Creating Tagger using model {spacy_model}")
    nlp = spacy.load(spacy_model)
    labels = nlp.pipe_labels.get("senter", [])
    ensure_tagger(nlp, "senter")
    model = Tagger(nlp, name="senter")
    stream = add_tokens(nlp, stream)  # add tokens for faster annotation
    stream = prefer_uncertain(model(stream), algorithm="probability")

    return {
        "view_id": "pos",
        "dataset": dataset,
        "stream": stream,
        "update": model.update,
        "exclude": exclude,
        "config": {
            "lang": nlp.lang,
            "labels": labels,
        },
    }


@recipe(
    "sent.correct",
    # fmt: off
    dataset=("Dataset to save annotations to", "positional", None, str),
    spacy_model=("Loadable spaCy pipeline with a senter", "positional", None, str),
    source=("Data to annotate (file path or '-' to read from standard input)", "positional", None, str),
    loader=("Loader (guessed from file extension if not set)", "option", "lo", str),
    exclude=("Comma-separated list of dataset IDs whose annotations to exclude", "option", "e", split_string),
    # fmt: on,
)
def make_gold(
    dataset: str,
    spacy_model: str,
    source: Union[str, Iterable[dict]],
    loader: Optional[str] = None,
    exclude: Optional[List[str]] = None,
) -> RecipeSettingsType:
    """
    Create gold data for sentence boundaries by correcting a model's
    predictions.
    """
    log("RECIPE: Starting recipe sent.correct", locals())
    nlp = spacy.load(spacy_model)
    log(f"RECIPE: Loaded model {spacy_model}")
    stream = get_stream(
        source, loader=loader, rehash=True, dedup=True, input_key="text"
    )
    stream = add_tokens(nlp, stream)  # add tokens for faster annotation

    def make_tasks(nlp: Language, stream: StreamType) -> StreamType:
        """Add a 'spans' key to each example, with predicted tags."""
        texts = ((eg["text"], eg) for eg in stream)
        for doc, eg in nlp.pipe(texts, as_tuples=True, batch_size=10):
            task = copy.deepcopy(eg)
            spans = []
            for i, token in enumerate(doc):
                if token.is_sent_start:
                    spans.append(
                        {
                            "token_start": i,
                            "token_end": i,
                            "start": token.idx,
                            "end": token.idx + len(token.text),
                            "text": token.text,
                            "label": SENT_START_LABEL,
                            "source": spacy_model,
                            "input_hash": eg[INPUT_HASH_ATTR],
                        }
                    )
            task["spans"] = spans
            task[BINARY_ATTR] = False
            task = set_hashes(task)
            yield task

    stream = make_tasks(nlp, stream)

    return {
        "view_id": "pos_manual",
        "dataset": dataset,
        "stream": stream,
        "exclude": exclude,
        "config": {
            "lang": nlp.lang,
            "labels": [SENT_START_LABEL],
            "exclude_by": "input",
            "auto_count_stream": True,
            "allow_newline_highlight": True,
        },
    }
