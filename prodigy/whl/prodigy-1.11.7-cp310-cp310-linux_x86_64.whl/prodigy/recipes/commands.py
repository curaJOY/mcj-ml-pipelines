from typing import List, Optional, Union, Tuple, Iterable
from pathlib import Path
import platform
import srsly
from peewee import OperationalError
from collections import Counter, defaultdict
from datetime import datetime

from .. import about
from ..core import recipe
from ..components.db import connect
from ..components.loaders import get_loader, get_stream
from ..util import PRODIGY_HOME, set_hashes, get_timestamp_session_id, split_string
from ..util import log, msg, TIMESTAMP_ATTR, INPUT_HASH_ATTR


@recipe(
    "stats",
    set_id=("Optional dataset to show stats for", "positional", None, str),
    list_datasets=("Print list of all datasets", "flag", "l", bool),
    list_sessions=("Print list of all sessions", "flag", "ls", bool),
    no_format=("Don't pretty-print results", "flag", "NF", bool),
    silent=("Don't print anything, just return", "flag", "S", bool),
)
def stats(
    set_id: Optional[str] = None,
    list_datasets: bool = False,
    list_sessions: bool = False,
    no_format: bool = False,
    silent: bool = False,
) -> None:
    """
    Print Prodigy and database statistics. Specifying a dataset ID will show
    detailed stats for the set.
    """
    DB = connect()
    stats = {
        "prodigy_stats": {
            "version": about.__version__,
            "location": str(Path(__file__).parent.parent),
            "prodigy_home": PRODIGY_HOME,
            "platform": platform.platform(),
            "python_version": platform.python_version(),
            "database_name": DB.db_name,
            "database_id": DB.db_id,
            "total_datasets": len(DB.datasets),
            "total_sessions": len(DB.sessions),
        }
    }
    if (list_datasets or list_sessions) and len(DB.datasets):
        stats["datasets"] = DB.datasets
    if list_sessions and len(DB.sessions):
        stats["sessions"] = DB.sessions
    if set_id:
        if set_id not in DB:
            msg.fail(f"Can't find '{set_id}' in database {DB.db_name}", exits=1)
        examples = DB.get_dataset(set_id)
        meta = DB.get_meta(set_id)
        decisions = Counter()
        for eg in examples:
            if "answer" in eg:
                decisions[eg["answer"]] += 1
            elif "spans" in eg:
                for span in eg["spans"]:
                    if "answer" in span:
                        decisions[span["answer"]] += 1
        stats["dataset_stats"] = {
            "dataset": set_id,
            "created": meta.get("created"),
            "description": meta.get("description"),
            "author": meta.get("author"),
            "annotations": len(examples),
            "accept": decisions["accept"],
            "reject": decisions["reject"],
            "ignore": decisions["ignore"],
        }
    if silent:
        return stats
    if no_format:
        print(srsly.json_dumps(stats))
    else:
        for key, values in stats.items():
            title = key.replace("_", " ").title()
            msg.divider(title, icon="emoji")
            if isinstance(values, list):
                msg.text(", ".join(values), spaced=True)
            else:
                msg.table({k.replace("_", " ").title(): v for k, v in values.items()})


@recipe(
    "drop",
    set_id=("Name of dataset to remove", "positional", None, str),
    batch_size=("Delete examples in batches of the given size", "option", "n", int),
)
def drop(set_id: str, batch_size: Optional[int] = None) -> None:
    """
    Remove a dataset. Can't be undone. For a list of all dataset and session
    IDs in the database, use `prodigy stats -ls`.
    """
    DB = connect()
    if set_id not in DB:
        msg.fail(f"Can't find '{set_id}' in database {DB.db_name}", exits=1)
    try:
        dropped = DB.drop_dataset(set_id, batch_size)
    except OperationalError as e:
        # See: https://support.prodi.gy/t/error-when-prodigy-drop/928
        if "too many SQL variables" in str(e):
            msg.fail(
                f"Unable to delete dataset '{set_id}' because a database limit "
                f"on the number of query variables was reached. On some systems "
                f"this limit is quite low, so using a custom batch size may "
                f"resolve the issue. Try: prodigy drop -n 500 {set_id}",
                exits=1,
            )
        else:
            msg.fail(f"Database error: unable to delete dataset '{set_id}'", e, exits=1)
    if not dropped:
        msg.fail(f"Can't remove '{set_id}' from database {DB.db_name}", exits=1)
    msg.good(f"Removed '{set_id}' from database {DB.db_name}", exits=1)


@recipe(
    "db-in",
    set_id=("Dataset to import annotations to", "positional", None, str),
    in_file=("Path to input annotation file", "positional", None, str),
    answer=("Set this answer key if none is present", "option", "a", str),
    overwrite=("DEPRECATED: Overwrite existing answers", "flag", "o", bool),
    loader=("DEPRECATED: loader to use", "option", "lo", str),
    rehash=("Update and overwrite all hashes", "flag", "rh", bool),
    dry=("Perform a dry run", "flag", "D", bool),
)
def db_in(
    set_id: str,
    in_file: Union[str, Path],
    loader: Optional[str] = None,
    answer: str = "accept",
    overwrite: bool = False,
    rehash: bool = False,
    dry: bool = False,
) -> None:
    """
    Import annotations to the database. Supports all formats loadable by
    Prodigy.
    """
    DB = connect()
    in_file = Path(in_file)
    if not in_file.exists() or not in_file.is_file():
        msg.fail("Not a valid input file", in_file, exits=1)
    loader = get_loader(loader, file_path=in_file)
    annotations = loader(in_file)
    annotations = [set_hashes(eg) for eg in annotations]
    added_answers = 0
    for task in annotations:
        if "answer" not in task or overwrite:
            task["answer"] = answer
            added_answers += 1
        if rehash:
            task = set_hashes(task, overwrite=True)
    session_id = get_timestamp_session_id()
    if not dry:
        if set_id not in DB:
            DB.add_dataset(set_id)
            msg.good(f"Created dataset '{set_id}' in database {DB.db_name}")
        DB.add_dataset(session_id, session=True)
        DB.add_examples(annotations, datasets=[set_id, session_id])
    n_total = len(annotations)
    msg.good(
        f"Imported {n_total} annotations to '{set_id}' (session {session_id}) in database {DB.db_name}",
        f'Found and keeping existing "answer" in {n_total - added_answers} examples',
    )


@recipe(
    "db-out",
    set_id=("Name of dataset to export", "positional", None, str),
    out_dir=("Path to output directory", "positional", None, str),
    answer=("Only export annotations with this answer", "option", "a", str),
    flagged_only=("DEPRECATED: Only export flagged annotations", "flag", "F", bool),
    dry=("Perform a dry run", "flag", "D", bool),
)
def db_out(
    set_id: str,
    out_dir: Optional[Union[str, Path]] = None,
    answer: str = None,
    flagged_only: bool = False,
    dry: bool = False,
) -> None:
    """
    Export annotations from the database. Files will be exported in
    Prodigy's JSONL format.
    """
    DB = connect()
    if set_id not in DB:
        msg.fail(f"Can't find '{set_id}' in database {DB.db_name}", exits=1)
    examples = DB.get_dataset(set_id)
    if flagged_only:
        examples = [eg for eg in examples if eg.get("flagged")]
    if answer:
        examples = [eg for eg in examples if eg.get("answer") == answer]
    if out_dir is None:
        for eg in examples:
            print(srsly.json_dumps(eg))
    else:
        out_dir = Path(out_dir)
        if not out_dir.exists():
            out_dir.mkdir()
        out_file = out_dir / f"{set_id}.jsonl"
        if not dry:
            srsly.write_jsonl(out_file, examples)
        msg.good(
            f"Exported {len(examples)} annotations from '{set_id}' in database {DB.db_name}",
            out_file.resolve(),
        )


@recipe(
    "db-merge",
    in_sets=("Comma-separated datasets to merge", "positional", None, split_string),
    out_set=("Name of new dataset for merged data", "positional", None, str),
    rehash=("Force-update all task and input hashes", "flag", "R", bool),
    dry=("Perform a dry run", "flag", "D", bool),
)
def db_merge(
    in_sets: List[str], out_set: str, rehash: bool = False, dry: bool = False
) -> None:
    """
    Merge two or more existing datasets into a new set. Keeps a copy of the
    original datasets and creates a new set for the merged examples.
    """
    DB = connect()
    for set_id in in_sets:
        if set_id not in DB:
            msg.fail(f"Can't find dataset '{set_id}' in database", exits=1)
    if out_set in DB and len(DB.get_dataset(out_set)):
        msg.fail(
            f"Output dataset '{out_set}' already exists and includes examples",
            "This can lead to unexpected results. Please use a new dataset.",
            exits=1,
        )
    if out_set not in DB:
        if not dry:
            DB.add_dataset(out_set)
        msg.good(f"Created dataset '{out_set}'")
    merged = []
    for set_id in in_sets:
        examples = DB.get_dataset(set_id)
        if rehash:
            examples = [set_hashes(eg, overwrite=True) for eg in examples]
        merged += examples
        log(f"RECIPE: Adding {len(examples)} examples from '{set_id}'")
    if not dry:
        DB.add_examples(merged, datasets=[out_set])
    msg.good(
        f"Merged {len(merged)} examples from {len(in_sets)} datasets",
        f"Created merged dataset '{out_set}'",
    )


@recipe(
    "progress",
    # fmt: off
    datasets=("Comma-separated datasets to use", "positional", None, split_string),
    interval=("Interval to calculate progress for", "option", "i", str, ["day", "week", "month", "year"]),
    source=("Optional source data to use for progress calculation (file path or '-' to read from standard input)", "option", "s", str),
    loader=("Loader for source (guessed from file extension if not set)", "option", "lo", str),
    # fmt: on
)
def progress(
    datasets: List[str],
    interval: str = "month",
    source: Union[str, Iterable[dict]] = None,
    loader: Optional[str] = None,
) -> List[List[Union[str, int]]]:
    """
    View the progress on one or more datasets over time. Uses the timestamp
    added to annotations in Prodigy v1.11+ to group annotations and falls back
    to dataset creation timestamp for data created with older versions. If a
    source is provided, the annotations will be compared against the examples in
    the data to calculate the percentage of how many examples in the data are
    annotated.
    """

    def get_timestamp_key(
        ts: datetime, interval: str
    ) -> Tuple[Tuple[int, int, int, int], str]:
        year = ts.year
        month = ts.strftime("%b")
        week = ts.strftime("%V")
        day = ts.strftime("%d")
        if interval == "year":
            return ((ts.year, 0, 0, 0), f"{year}")
        if interval == "month":
            return ((ts.year, ts.month, 0, 0), f"{month} {year}")
        if interval == "week":
            return ((ts.year, ts.month, int(week), 0), f"{month} {year} (week {week})")
        if interval == "day":
            return ((ts.year, ts.month, int(week), ts.day), f"{day} {month} {year}")
        raise ValueError(f"Invalid interval: {interval}")

    DB = connect()
    all_examples = []
    n_examples = 0
    for set_id in set(datasets):
        if set_id not in DB:
            msg.fail(f"Can't find dataset '{set_id}' in database", exits=1)
        examples = DB.get_dataset(set_id)
        meta = DB.get_meta(set_id)  # keep meta for created timestamp fallback
        all_examples.append((examples, set_id, meta["created"]))
        n_examples += len(examples)
    msg.good(f"Loaded {n_examples} annotations from {len(datasets)} datasets")

    source_hashes = None
    if source is not None:
        stream = get_stream(source, loader=loader, rehash=True, dedup=True)
        source_hashes = set([eg[INPUT_HASH_ATTR] for eg in stream])
        msg.good(f"Loaded {len(source_hashes)} unique examples from source")

    examples_by_ts = Counter()
    uniques_by_ts = defaultdict(set)
    print_keys_by_ts = {}
    no_ts_count = 0
    no_ts_sets = set()
    for examples, name, created in all_examples:
        for eg in examples:
            timestamp = eg.get(TIMESTAMP_ATTR)
            if timestamp:
                ts = datetime.utcfromtimestamp(timestamp)
            else:
                ts = created
                no_ts_count += 1
                no_ts_sets.add(name)
            key, print_key = get_timestamp_key(ts, interval)
            examples_by_ts[key] += 1
            uniques_by_ts[key].add(eg[INPUT_HASH_ATTR])
            print_keys_by_ts[key] = print_key
    data = []
    cumsum = 0
    cumsum_unique = 0
    for key, counts in sorted(examples_by_ts.items()):
        uniques = uniques_by_ts[key]
        cumsum += counts
        cumsum_unique += len(uniques)
        row = [print_keys_by_ts[key], counts, len(uniques), cumsum, cumsum_unique]
        if source_hashes is not None:
            annots = [eg_hash for eg_hash in uniques if eg_hash in source_hashes]
            row.append(len(annots))
            row.append(f"{len(annots) / len(source_hashes):.1%}")
        data.append(row)
    header = ["", "New", "Unique", "Total", "Unique"]
    aligns = ["l", "r", "r", "r", "r"]
    info = {
        "New": "New annotations collected in interval",
        "Total": "Total annotations collected",
        "Unique": "Unique examples (not counting multiple annotations of same example)",
    }
    if source_hashes is not None:
        header += ["In source", "Progress"]
        aligns += ["r", "r"]
        info["In source"] = "Total annotations on examples in source data"
        info["Progress"] = "Percentage of examples annotated in source data"
    msg.table(info, title="Legend")
    msg.table(
        data, title="Annotation Progress", header=header, aligns=aligns, divider=True
    )
    if no_ts_count:
        msg.warn(
            f'No "{TIMESTAMP_ATTR}" found in {no_ts_count} annotations from '
            f"datasets: {', '.join(no_ts_sets)}. Maybe the data was created "
            f"with Prodigy v1.10 or lower? Using dataset creation time as a fallback."
        )
    return data
