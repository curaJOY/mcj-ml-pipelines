from typing import Iterable
import signal
from collections import defaultdict


def sort_recipes(recipes: Iterable[str]) -> Iterable[str]:
    result = defaultdict(list)
    for recipe in recipes:
        if "." in recipe:  # try to group recipes of the same type together
            prefix = recipe.split(".", 1)[0]
            result[prefix].append(recipe)
        else:
            result["other"].append(recipe)
    return result.values()


if __name__ == "__main__":
    from prodigy.core import get_recipe, list_recipes, Controller, import_code
    from prodigy.app import server
    from prodigy.util import get_valid_sessions, msg, log, registry
    import sys

    valid_sessions = get_valid_sessions()
    if valid_sessions is not None:
        log(f"CLI: limiting user sessions to list: {', '.join(valid_sessions)}")
    help_args = ("--help", "-h", "help")
    if len(sys.argv) == 1 or (len(sys.argv) == 2 and sys.argv[1] in help_args):
        recipes = list_recipes()
        sorted_recipes = sort_recipes(recipes)
        msg.divider("Available recipes", icon="emoji")
        for options in sort_recipes(recipes):
            print("")
            msg.text(", ".join(options))
        sys.exit(0)

    command = sys.argv.pop(1)
    sys.argv[0] = f"prodigy {command}"
    args = sys.argv[1:]

    paths = []
    if "-F" in args:
        paths = args.pop(args.index("-F") + 1)
        args.pop(args.index("-F"))
        paths = [path.strip() for path in paths.split(",")]

    # Just load the entry points here so the decorator runs and sets them
    # properly. Don't add them to the registry, because the functions will
    # be wrong (original recipe, not the recipe proxy). Also beware of circular
    # imports – we can't just call this in util etc., because that may be
    # imported by third-party packages.
    registry.recipes.get_entry_points()

    # Import all code provided as paths (recipes, registered functions)
    for path in paths:
        log(f"CLI: Importing file {path}")
        import_code(path)

    recipe = get_recipe(command)
    if recipe:
        try:
            controller = recipe(*args, use_plac=True)
        except BrokenPipeError:
            # We catch the BrokenPipeError here to handle Unix pipes that break
            # The signal handler is still needed
            # See: https://stackoverflow.com/a/16865106/6400719
            # And: https://docs.python.org/3/library/signal.html#note-on-sigpipe
            # E.g. in Bash (doesn't happen in Zsh)
            # python -m prodigy db-out ner_fashion | bash -c "exit 1"
            signal.signal(signal.SIGPIPE, signal.SIG_DFL)
            sys.exit()
        # It's okay to check for an instance of Controller here – there are
        # really no cases where people want to pass in a custom object that
        # works like a controller. The previous hacky check for an attribute
        # "config" meant that Prodigy would accept an instance of Language,
        # which leads to confusing errors.
        if isinstance(controller, Controller):
            # The server is out of the BrokenPipeError because Uvicorn has its own
            # handlers, as when a client disconnects in the middle of a response
            # (closes the socket) some systems (e.g. containers) send a SIGPIPE to
            # the process. And if this was in the same try block, a disconnection would
            # terminate the server.
            server(controller, controller.config)
    else:
        opts = [r for r in list_recipes() if command in r]
        help_text = "Run prodigy --help to see available options."

        info = f"Similar recipes: {', '.join(opts)}." if len(opts) else help_text
        err = f"Can't find recipe or command '{command}'."
        if paths:
            err += " It's not a built-in recipe and not available in the provided file paths."
        else:
            info += " If you're using a custom recipe, provide the path to the Python file using the -F argument."
        msg.fail(err, info, exits=1)
