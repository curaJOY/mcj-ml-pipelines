from .ner import EntityRecognizer, merge_spans  # noqa: F401
from .dep import DependencyParser, merge_arcs  # noqa: F401
from .tag import Tagger, merge_tags  # noqa: F401
