from typing import Optional, Dict, Any, Tuple, List, Union, Iterable, Set
import peewee as orm
from pathlib import Path
import tempfile
import os
from shutil import copyfile
from toolz import partition_all
import srsly
import sys

from ..util import PRODIGY_HOME, TASK_HASH_ATTR, INPUT_HASH_ATTR, log, registry
from ..util import ENV_VARS, get_config, convert_blob, get_display_name
from ..types import TaskType

try:
    from contextvars import ContextVar

    db_state_default = {"closed": None, "conn": None, "ctx": None, "transactions": None}
    db_state = ContextVar("db_state", default=db_state_default.copy())
except ImportError:
    ContextVar = None
    db_state_default = None

# Reset contextvars on Python 3.6 to discard backport incompatible with asyncio
if sys.version_info[0] == 3 and sys.version_info[1] < 7:
    ContextVar = None
    db_state_default = None


DB_PROXY = orm.Proxy()
_DB = None
DEFAULT_MYSQL_MAX_LEN = 65535


def get_db() -> None:
    """Get access to the shared database instance that was previously connected"""
    global _DB
    return _DB


def set_db(instance: "Database") -> None:
    """Set the shared database instance. Mostly useful for testing."""
    global _DB
    if _DB is not None:
        disconnect()
    _DB = instance


def disconnect() -> None:
    """Disconnect the shared database instance and revert it back to None type"""
    global _DB
    if _DB is None:
        raise AssertionError("Database is already destroyed")
    _DB.close()
    _DB = None


def connect(
    db_id: Optional[str] = None, db_settings: Optional[Dict[str, Any]] = None
) -> "Database":
    """Connect to the database.

    db_id (str): 'sqlite' (default), 'postgresql' or 'mysql'.
    db_settings (dict): Optional database connection parameters.
    RETURNS (prodigy.components.db.Database): The initialized database.
    """
    global _DB
    if _DB is not None:
        return _DB
    connectors = {
        "sqlite": connect_sqlite,
        "postgresql": connect_postgresql,
        "mysql": connect_mysql,
    }
    config = get_config()
    if db_id in (True, False, None):
        db_id = config.get("db", "sqlite")
    if db_settings in (True, False, None):
        config_db_settings = config.setdefault("db_settings", {})
        db_settings = config_db_settings.get(db_id, {})
    if db_id in registry.databases:
        return registry.databases.get(db_id)
    if db_id not in connectors:
        raise ValueError(f"Invalid database id: {db_id}")
    db_name, db = connectors[db_id](**db_settings)
    _DB = Database(db, db_id, db_name)
    log(f"DB: Connecting to database {db_name}")
    return _DB


class BaseORMModel(orm.Model):
    class Meta:
        database = DB_PROXY


class Dataset(BaseORMModel):
    name = orm.CharField(unique=True)
    created = orm.TimestampField()
    meta = orm.BlobField()
    session = orm.BooleanField()


class Example(BaseORMModel):
    input_hash = orm.BigIntegerField()
    task_hash = orm.BigIntegerField()
    content = orm.BlobField()

    def load(self) -> Dict[str, Any]:
        content = convert_blob(self.content)
        return srsly.json_loads(content)

    def serialize(self) -> Dict[str, Any]:
        content = convert_blob(self.content)
        return {
            "id": self.id,
            "content": srsly.json_loads(content),
            "input_hash": self.input_hash,
            "task_hash": self.task_hash,
        }


class Link(BaseORMModel):
    example = orm.ForeignKeyField(Example)
    dataset = orm.ForeignKeyField(Dataset)


if ContextVar is not None:
    # Monkeypatch Peewee
    # ref: https://fastapi.tiangolo.com/advanced/sql-databases-peewee/
    class PeeweeConnectionState(orm._ConnectionState):
        def __init__(self, **kwargs):
            super().__setattr__("_state", db_state)
            super().__init__(**kwargs)

        def __setattr__(self, name, value):
            self._state.get()[name] = value

        def __getattr__(self, name):
            return self._state.get()[name]


else:
    PeeweeConnectionState = orm._ConnectionLocal


def connect_sqlite(**settings) -> Tuple[str, orm.SqliteDatabase]:
    database = settings.pop("name", "prodigy.db")
    path = settings.pop("path", PRODIGY_HOME)
    if database != ":memory:":
        database = str(Path(path) / database)
    settings["check_same_thread"] = settings.get("check_same_thread", False)
    # Enable SQLite foreign key constraints
    settings["pragmas"] = settings.get("pragmas", [("foreign_keys", 1)])
    db = orm.SqliteDatabase(database, **settings)
    return "SQLite", db


def connect_postgresql(**settings) -> Tuple[str, orm.PostgresqlDatabase]:
    database = "prodigy"
    for setting in ("db", "name", "dbname", "database"):
        if setting in settings:
            database = settings.pop(setting)
    db = orm.PostgresqlDatabase(database, **settings)
    return "PostgreSQL", db


def connect_mysql(**settings) -> Tuple[str, orm.MySQLDatabase]:
    database = "prodigy"
    for setting in ("db", "name", "dbname", "database"):
        if setting in settings:
            database = settings.pop(setting)
    db = orm.MySQLDatabase(database, **settings)
    return "MySQL", db


DB_TABLES = [Dataset, Example, Link]


class Database:
    def __init__(
        self,
        db: orm.Database,
        display_id: str = "custom",
        display_name: Optional[str] = None,
    ) -> None:
        """Initialize a database.

        db: A database object that can be initialized by peewee.
        display_id (str): Database ID used for logging, e.g. 'sqlite'.
        display_name (str): Database name used for logging, e.g. 'SQLite'.
        RETURNS (Database): The initialized database.
        """
        # Monkeypatch Peewee
        # ref: https://fastapi.tiangolo.com/advanced/sql-databases-peewee/
        db._state = PeeweeConnectionState()
        DB_PROXY.initialize(db)
        self.db_id = display_id
        self.db_name = display_name or get_display_name(db)
        log(f"DB: Initializing database {self.db_name}")
        try:
            DB_PROXY.create_tables(DB_TABLES, safe=True)
        except orm.OperationalError:
            pass
        self.db = DB_PROXY

    def __bool__(self) -> bool:
        return True

    def __len__(self) -> int:
        """
        RETURNS (int): The number of datasets in the database.
        """
        return len(self.datasets)

    def __contains__(self, name: str) -> bool:
        """
        name (str): Name of the dataset.
        RETURNS (bool): Whether the dataset exists in the database.
        """
        try:
            has_ds = bool(Dataset.get(Dataset.name == name))
        except Dataset.DoesNotExist:
            has_ds = False
        return has_ds

    @property
    def datasets(self) -> List[str]:
        """
        RETURNS (list): A list of dataset IDs.
        """
        datasets = (
            Dataset.select(Dataset.name)
            .where(Dataset.session == False)  # noqa: E712
            .order_by(Dataset.created)
        )
        return [ds.name for ds in datasets]

    @property
    def sessions(self) -> List[str]:
        """
        RETURNS (list): A list of session dataset IDs.
        """
        datasets = (
            Dataset.select(Dataset.name)
            .where(Dataset.session == True)  # noqa: E712
            .order_by(Dataset.created)
        )
        return [ds.name for ds in datasets]

    def close(self) -> None:
        """
        Close the database connection (if not already closed). Called after
        API requests to avoid timeout issues, especially with MySQL.
        """
        if not self.db.is_closed():
            self.db.close()

    def reconnect(self) -> None:
        """
        Reconnect to the database. Called on API requests to avoid timeout
        issues, especiallly with MySQL. If the database connection is still
        open, it will be closed before reconnecting.
        """
        if not self.db.is_closed():
            self.db.close()
        self.db.connect()

    def get_examples(
        self, ids: Union[Iterable[int], int], by: str = "task_hash"
    ) -> List[TaskType]:
        """
        ids (list): List of example hashes.
        by (str): ID to get examples by. Defaults to 'task_hash'.
        RETURNS (list): The examples.
        """
        try:
            ids = list(ids)
        except TypeError:
            ids = [ids]
        field = getattr(Example, by)
        ids = list(ids)
        return [eg.load() for eg in Example.select().where(field << ids)]

    def get_meta(self, name: str) -> Dict[str, Any]:
        """
        name (str): The dataset name.
        RETURNS (dict): The dataset meta.
        """
        if name not in self:
            return None
        dataset = Dataset.get(Dataset.name == name)
        meta = convert_blob(dataset.meta)
        meta = srsly.json_loads(meta)
        meta["created"] = dataset.created
        return meta

    def get_sessions_examples(
        self, session_ids: Optional[Iterable[str]] = None
    ) -> List[TaskType]:
        """
        session_ids (list): A list of session IDs to gather examples from
        RETURNS (list): The examples linked to the given sessions.
        """
        if session_ids is None or len(session_ids) == 0:
            raise ValueError("One or more sessions are required")
        query = (
            Example.select(Example, Link, Dataset)
            .join(Link)
            .where(Dataset.name << session_ids)
            .join(Dataset)
        )
        # Tag each example with `session_id` so it can be mapped
        # back to the original session later if needed.
        examples = []
        for eg in query:
            example = eg.load()
            session_id = eg.link.dataset.name
            example["session_id"] = session_id
            examples.append(example)
        log(f"DB: Retrieved {len(examples)} examples from {len(session_ids)} sessions")
        return examples

    def count_dataset(self, name: str, session: bool = False) -> int:
        """
        name (str): The dataset name.
        session: Return only session datasets when True.
        RETURNS (int): The number of examples in the dataset.
        """
        if name not in self:
            raise ValueError(f"Can't find dataset '{name}' in database {self.db_name}")
        dataset = Dataset.get(Dataset.name == name)
        query = (
            Example.select().join(Link).join(Dataset).where(Dataset.id == dataset.id)
        )
        if session is True:
            query = query.where(Dataset.session == True)  # noqa: E712
        examples = query.execute()
        return len(examples)

    def get_dataset(
        self, name: str, default: Optional[Any] = None, session: bool = False
    ) -> List[TaskType]:
        """
        name (str): The dataset name.
        default: Return value if dataset not in database.
        session: Return only session datasets when True.
        RETURNS (list): The examples in the dataset or default value.
        """
        if name not in self:
            return default
        dataset = Dataset.get(Dataset.name == name)
        query = (
            Example.select().join(Link).join(Dataset).where(Dataset.id == dataset.id)
        )
        if session is True:
            query = query.where(Dataset.session == True)  # noqa: E712
        examples = query.execute()
        log(f"DB: Loading dataset '{name}' ({len(examples)} examples)")
        return [eg.load() for eg in examples]

    def get_dataset_page(
        self, name: str, page_number: int, page_size: int
    ) -> Tuple[List[TaskType], int]:
        """
        Get a page of dataset examples. This is useful for paginating API endpoints.
        name (str): The dataset name.
        page_number (int): The page number to retrieve
        page_size (int): The number of items to return in a page
        RETURNS (list, int): A tuple of the requested page of examples as a list
        and the total count in the dataset.
        """
        if name not in self:
            return [], -1
        dataset = Dataset.get(Dataset.name == name)
        query = (
            Example.select().join(Link).join(Dataset).where(Dataset.id == dataset.id)
        )
        count = query.count()
        examples = query.paginate(page_number, page_size).execute()
        log(
            f"DB: Loading dataset '{name}' page {page_number} ({len(examples)} examples)"
        )
        return ([eg.serialize() for eg in examples], count)

    def get_input_hashes(self, *names) -> Set[int]:
        """
        *names (str): Dataset names to get hashes for.
        RETURNS (set): The input hashes.
        """
        datasets = Dataset.select(Dataset.id).where(Dataset.name << names)
        examples = (
            Example.select(Example.input_hash)
            .join(Link)
            .join(Dataset)
            .where(Dataset.id << datasets)
        ).execute()
        return set([eg.input_hash for eg in examples])

    def get_task_hashes(self, *names) -> Set[int]:
        """
        *names (str): The dataset names.
        RETURNS (set): The task hashes.
        """
        datasets = Dataset.select(Dataset.id).where(Dataset.name << names)
        examples = (
            Example.select(Example.task_hash)
            .join(Link)
            .join(Dataset)
            .where(Dataset.id << datasets)
        ).execute()
        return set([eg.task_hash for eg in examples])

    def add_dataset(
        self, name: str, meta: Dict[str, Any] = {}, session: bool = False
    ) -> list:
        """
        name (str): The name of the dataset to add.
        meta (dict): Optional dataset meta.
        session (bool): Whether the dataset is a session dataset.
        RETURNS (list): The created dataset.
        """
        if any([char in name for char in (",", " ")]):
            raise ValueError("Dataset name can't include commas or whitespace")
        try:
            dataset = Dataset.get(Dataset.name == name)
            log(f"DB: Getting dataset '{name}'")
        except Dataset.DoesNotExist:
            log(f"DB: Creating dataset '{name}'", meta)
            meta = srsly.json_dumps(meta)
            dataset = Dataset.create(name=name, meta=meta, session=session)
        return dataset

    def add_examples(
        self, examples: Iterable[TaskType], datasets: Iterable[str] = tuple()
    ) -> None:
        """
        examples (list): The examples to add.
        datasets (list): The names of the dataset(s) to add the examples to.
        """
        with self.db.atomic():
            ids = []
            for eg in examples:
                content = srsly.json_dumps(eg)
                max_len = int(os.getenv(ENV_VARS.MYSQL_MAX_LEN, DEFAULT_MYSQL_MAX_LEN))
                if self.db_id == "mysql" and len(content) >= max_len:
                    raise ValueError(
                        f"Can't add JSON example to MySQL database: blob is "
                        f"longer than {max_len} characters. This can lead "
                        f"to MySQL truncating your data. If possible, segment "
                        f"your examples into smaller chunks or limit what you're "
                        f"including in the data. You can also change the field "
                        f"type to mediumblob and set the environment variable "
                        f"{ENV_VARS.MYSQL_MAX_LEN}=16777215.\n"
                        f"ALTER TABLE example MODIFY content mediumblob;"
                    )
                eg = Example.create(
                    input_hash=eg[INPUT_HASH_ATTR],
                    task_hash=eg[TASK_HASH_ATTR],
                    content=content,
                )
                ids.append(eg.id)
        if type(datasets) is not tuple and type(datasets) is not list:
            raise ValueError(f"Datasets must be a tuple or list, not: {type(datasets)}")
        for dataset in datasets:
            self.link(dataset, ids)
        log(f"DB: Added {len(examples)} examples to {len(datasets)} datasets")

    def link(self, dataset_name: str, example_ids: Iterable[int]) -> None:
        """
        dataset_name (str): The name of the dataset.
        example_ids (iterable): The IDs of the examples to link to the dataset.
        """
        with self.db.atomic():
            dataset = self.add_dataset(dataset_name)
            for eg in example_ids:
                _ = Link.create(dataset=dataset.id, example=eg)

    def unlink(self, dataset: str) -> None:
        """
        dataset (str): The name of the dataset to unlink.
        """
        dataset = Dataset.get(Dataset.name == dataset)
        query = Link.delete().where(Dataset.id == dataset.id)
        query.execute()

    def drop_dataset(self, name: str, batch_size: Optional[int] = None) -> bool:
        """
        name (str): The name of the dataset to drop.
        batch_size (int): If specified examples will be deleted in batches of the given size.
        RETURNS (bool): True if dataset was dropped.
        """

        with self.db.atomic():
            log(f"DB: Dropping dataset '{name}'")
            #  Use strong reference counting to free Examples by looking
            #  at how many times an example is referenced by Links and only
            #  deleting it when the final referencing Link goes away.
            dataset = Dataset.get(Dataset.name == name)
            links = Link.select().where(Link.dataset == dataset.id)
            # Grab all the example ids before we delete the links
            original_example_ids = [link.example.id for link in links]
            log(f"DB: Found {len(original_example_ids)} examples to unlink")
            Link.delete().where(Link.dataset == dataset.id).execute()
            Dataset.delete().where(Dataset.id == dataset.id).execute()
            batches = [original_example_ids]
            if batch_size is not None:
                # Convert ID list into a generator to partition large lists nicely.
                def link_id_stream(input):
                    for id in input:
                        yield id

                batches = partition_all(
                    batch_size, link_id_stream(original_example_ids)
                )
            for batch in batches:
                # Count references for each example
                link_examples = Link.select().where(Link.example_id << batch).execute()
                if len(link_examples) == 0:
                    # All the original links were deleted, so the delete list is
                    # batch
                    to_delete_example_ids = batch
                    log("DB: All batch example links were removed")
                else:
                    # Group the links into a dict of counts {example_id: count}
                    link_counts = {}
                    link_by_id = {}
                    for link in link_examples:
                        key = link.example_id
                        link_by_id[key] = link
                        if key not in link_counts:
                            link_counts[key] = 0
                        if link.dataset.session is not True:
                            # Skip counting non-session datasets. They only contain
                            # examples because of the sessions that insert them. If
                            # all sessions are gone, the example linked to the dataset
                            # is unlinked.
                            continue
                        link_counts[key] += 1
                    # reference count (v) == 0 for items that can be deleted
                    to_delete_example_ids = [
                        k for k, v in link_counts.items() if v == 0
                    ]
                    to_delete_links = [link_by_id[k].id for k in to_delete_example_ids]
                    # We need to remove any links identified for removal. This will only include
                    # links being removed from non-session datasets as a result of their session
                    # reference counts hitting 0.
                    Link.delete().where(Link.id << to_delete_links).execute()
                    log(
                        f"DB: {len(to_delete_example_ids)} out of {len(link_examples)} examples with 0 ref-count"
                    )
                # Delete the examples that are no longer referenced.
                if len(to_delete_example_ids) > 0:
                    Example.delete().where(
                        Example.id << to_delete_example_ids
                    ).execute()
                    log(f"DB: Deleted {len(to_delete_example_ids)} examples")
            self.db.commit()
        log(f"DB: Removed dataset '{name}'")
        return True

    def drop_examples(self, ids: Iterable[int], by: str = "task_hash") -> None:
        """
        ids (iterable): The IDs of the examples to drop.
        by (str): ID to get examples by. Defaults to 'task_hash'.
        """
        try:
            ids = list(ids)
        except TypeError:
            ids = [ids]
        field = getattr(Example, by)
        ids = list(ids)
        with self.db.atomic():
            example_ids = [e.id for e in Example.select(Example.id).where(field << ids)]
            Link.delete().where(Link.example << example_ids).execute()
            Example.delete().where(field << ids).execute()
            self.db.commit()

    def save(self) -> None:
        log("DB: Saving database")
        self.reconnect()
        self.db.commit()

    def export_session(self, session_id: str) -> Dict[str, Any]:
        log(f"DB: Exporting session '{session_id}'")
        if session_id is None:
            raise ValueError("session_id is required to export a session")
        if session_id not in self:
            raise ValueError("session does not exist in db")
        examples = self.get_dataset(session_id)
        if len(examples) == 0:
            return None
        result = self.add_to_exports(examples, session_id)
        log(f"DB: Exported {len(examples)} examples to {result}")
        return {"total": len(examples), "file": result}

    def trash_session(self, session_id: Optional[str] = None) -> Dict[str, Any]:
        """Delete a session and add its examples into the trash folder.

        RETURNS (tuple): number_deleted, trash_file"""
        log(f"DB: Trashing session {session_id}")
        results = []
        trash_file = None
        if session_id is None:
            raise ValueError("session_id is required")
        if session_id in self:
            results = self.get_dataset(session_id)
            trash_file = self.add_to_trash(results, session_id)
            self.drop_dataset(session_id)
        log(f"DB: Moved {len(results)} examples to the trash.")
        return {"total": len(results), "file": str(trash_file)}

    def add_to_trash(self, examples: Iterable[TaskType], base_path: str) -> str:
        """Move a set of examples out of the database into the PRODIGY_TRASH folder

        RETURNS (str): the exported file path
        """
        log(f"DB: Moving {len(examples)} examples to trash: {base_path}")
        out_path = get_trash_path()
        return self.write_examples(examples, out_path, base_path)

    def add_to_exports(self, examples: Iterable[TaskType], base_path: str) -> str:
        """Write a set of examples from the database into the exports folder

        RETURNS (str): the exported file path
        """
        log(f"DB: Exporting {len(examples)} examples from session: {base_path}")
        out_path = get_exports_path()
        return self.write_examples(examples, out_path, base_path)

    def write_examples(
        self, examples: Iterable[TaskType], folder_name: str, file_base: str
    ) -> str:
        """Write a set of examples into a folder/file while dealing with conflicts
        by using incrementing suffixes on the given file_base.

        RETURNS (str): the exported file path
        """
        # We write the examples to a file, then move it into the destination.
        # This avoids thrashing virtual file-systems like GCSFuse with a bunch
        # of writes, by making it a single (maybe large) copy operation.
        fd, tmp_file = tempfile.mkstemp()
        out_file = get_unique_file_name(folder_name, file_base)
        srsly.write_jsonl(tmp_file, examples)
        # Copy the file instead of renaming because we might cross device boundaries
        # into a VFS and that operation may not be supported.
        copyfile(tmp_file, str(out_file))
        os.close(fd)
        os.remove(tmp_file)
        return str(out_file)

    def export_sessions(
        self, session_ids: Iterable[str], export_name: str
    ) -> Dict[str, Any]:
        """Export examples from a list of given sessions"""
        examples = self.get_sessions_examples(session_ids)
        result = self.add_to_exports(examples, export_name)
        return {"total": len(examples), "file": result}

    def trash_sessions(
        self, session_ids: Iterable[str], export_name: str
    ) -> Dict[str, Any]:
        """Delete all examples from a list of given sessions"""
        examples = self.get_sessions_examples(session_ids)
        result = self.add_to_trash(examples, export_name)
        for session_id in session_ids:
            if session_id in self:
                self.drop_dataset(session_id)
        return {"total": len(examples), "file": result}

    def export_collection(
        self, sessions_ids_dict: Dict[str, Iterable[str]], collection_name: str
    ) -> Dict[str, Any]:
        """Export a key/value collection of session_ids groups"""
        folder = Path(get_unique_folder_name(get_exports_path(), collection_name))
        folder.mkdir(parents=True)
        meta_file = folder / "index.json"
        index = {"root": str(folder)}
        count = 0
        for group_key, session_ids in sessions_ids_dict.items():
            session_ids.sort()
            examples = self.get_sessions_examples(session_ids)
            examples_len = len(examples)
            count = count + examples_len
            result = self.add_to_exports(examples, folder / group_key)
            index[group_key] = {
                "file": result,
                "count": examples_len,
                "sessions": session_ids,
            }
        srsly.write_json(meta_file, index)
        return {"total": count, "file": str(meta_file)}

    def trash_collection(
        self, sessions_ids_dict: Dict[str, Iterable[str]], collection_name: str
    ) -> Dict[str, Any]:
        """Remove a collection of sessions and the associated examples from the database"""
        folder = Path(get_unique_folder_name(get_trash_path(), collection_name))
        folder.mkdir(parents=True)
        meta_file = folder / "index.json"
        index = {"root": str(folder)}
        count = 0
        # Iterate the collection and export backups
        for group_key, session_ids in sessions_ids_dict.items():
            session_ids.sort()
            examples = self.get_sessions_examples(session_ids)
            examples_len = len(examples)
            count = count + examples_len
            result = self.add_to_trash(examples, folder / group_key)
            index[group_key] = {
                "file": result,
                "count": examples_len,
                "sessions": session_ids,
            }
        # Iterate the collection again to remove the referenced examples. If we
        # did this above, only the first interested group would get a chance to
        # reference any given example.
        for group_key, session_ids in sessions_ids_dict.items():
            for session_id in session_ids:
                if session_id in self:
                    self.drop_dataset(session_id)
        srsly.write_json(meta_file, index)
        return {"total": count, "file": str(meta_file)}


def get_unique_file_name(
    folder_name: Union[str, Path], file_base: str, file_extension: str = "jsonl"
) -> Path:
    """Get a file name based on the input arguments that is guaranteed to be
    unique in the target folder on disk.
    """
    out = Path(folder_name) / f"{file_base}.{file_extension}"
    count = 0
    while out.is_file() is True:
        out = Path(folder_name) / f"{file_base}.{count}.{file_extension}"
        count += 1
    return out


def get_unique_folder_name(parent_folder: Union[str, Path], folder_base: str) -> Path:
    """Get a folder name based on the input arguments that is guaranteed to be
    unique in the parent folder on disk.
    """
    parent = Path(parent_folder)
    out = parent / folder_base
    count = 0
    while out.is_dir() is True:
        out = parent / f"{folder_base}.{count}"
        count += 1
    return out


def get_data_path(
    env_key: Optional[str] = None, fallback_name: Optional[str] = None
) -> str:
    root = Path(os.environ.get(env_key, get_prodigy_path(fallback_name)))
    result_folder = Path(root)
    if not result_folder.exists():
        result_folder.mkdir()
    return str(result_folder)


def get_trash_path() -> str:
    return get_data_path(ENV_VARS.TRASH, "trash")


def get_exports_path() -> str:
    return get_data_path(ENV_VARS.EXPORTS, "exports")


def get_prodigy_path(sub_folder: Optional[str] = None) -> str:
    """Get the full path to either the active prodigy folder, or a subfolder of
    it. First look in the current working directory for a prodigy file, and
    fallback to the PRODIGY_HOME folder of the current user.
    """
    root = Path(os.environ.get(ENV_VARS.HOME, Path.home() / ".prodigy"))
    cwd = Path.cwd()
    for filename in [".prodigy.json", "prodigy.json"]:
        if (cwd / filename).exists():
            root = cwd
    if sub_folder is not None:
        root = root / sub_folder
    return str(root)
